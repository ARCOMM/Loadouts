﻿#	Vanilla CSAT Hex Loadout
Vanilla CSAT Hex camo loadout with KH2002.


###	Special
MMG Team equipped with an HK121 9.3 mm MMG.
RAT utilizes RPG-32.
AR utilizes Negev NG7 7.62 mm.

###	General
*	3 bandages
*	1 morphine
*	1 tourniquet
*	2 frag grenades
*	2 smoke grenades
*	1 entrenching tool
*	1 map
*	1 compass
*	1 watch
*	1 handgun FNX 45 Tact

###	Specific
*	CO/DC/SQL
	*	GPS
	*	Binoculars
	*	6 HE GL	
	*	3 smoke GL white
	*	6 smoke GL red
	*	2 smoke GL green
	*	2 smoke GL blue
	*	1 smoke grenades blue / green / red	
	
*	FAC
	*	GPS
	*	Laser Designator
	*	4 HE GL
	*	2 smoke GL green
	*	2 smoke GL blue
	*	10 smoke GL red
	* 	6 smoke grenades green
	* 	6 smoke grenades blue
	* 	4 smoke grenades red

*	FTL
	*	GPS
	*	Binoculars
	*	8 HE GL
	*	1 smoke GL white
	*	4 smoke GL red
	*	2 smoke grenades green
	*	2 smoke grenades red

*	P/CP
	*	Vector ACP
	*	Slash Bandolier 
	*	3 30rnd ACP magazines
	*	2 smoke grenades white
	*	no handgun

	
	
*	VD
	*	GPS
	*	Scorpion Evo 3A1
	*	4 30rnd 9mm magazines
	*	Toolkit
	
*	VG
	*	GPS
	*	Scorpion Evo 3A1
	*	4 30rnd 9mm magazines
	
*	VC
	*	GPS
	*	Scorpion Evo 3A1
	*	4 30rnd 9mm magazines
	*	Binoculars

	
	
*	MMG
	*	HK121 9.3 mm medium machine gun (hex)
	*	3 150rnd 9.3 mm belts
	*	handgun FNX 45 Tact
	*	3 8rnd ACP
	
*	MMGAB
	*	Standard Rifleman
	*	4 150rnd 9.3 mm belts
	*	Binoculars
	
*	MMGTL
	*	Standard Fireteam Leader
	*	1 150rnd 9.3 mm belt
	
	
	
###	Addons required
*	Vanilla
*	ACE
*	CBA