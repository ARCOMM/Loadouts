﻿#	Vanilla CSAT Hex Loadout - Night
Vanilla CSAT Hex camo loadout with KH2002 and Gen8 NVGs.


###	Special
MMG Team equipped with an HK121 9.3 mm MMG.
RAT utilizes RPG-32.
AR utilizes Negev NG7 7.62 mm.

###	General
*	3 bandages
*	1 morphine
*	1 tourniquet
*	2 frag grenades
*	2 smoke grenades
*	1 entrenching tool
*	1 map
*	1 compass
*	1 watch
*	1 handgun FNX 45 Tact
*	1 Fulton MX991
*	3 Chemlights Red

###	Specific
*	CO/DC/SQL
	*	GPS
	*	Binoculars
	*	5 HE GL	
	*	1 smoke GL white
	*	3 smoke GL red
	*	2 smoke GL green
	*	1 smoke GL blue
	*	6 flare GL red
	*	4 flare GL yellow
	*	5 hand flare red
	*	3 hand flare green
	*	2 IR grenades
	*	1 smoke grenades blue / green / red	
	
*	FAC
	*	GPS
	*	Laser Designator
	*	4 HE GL
	*	2 smoke GL red
	*	2 smoke GL green
	*	1 smoke GL blue
	*	7 flare GL red
	*	6 flare GL green
	*	2 flare GL yellow
	*	1 flare GL white
	*	6 hand flare red
	*	4 hand flare green
	*	2 hand flare yellow
	*	2 smoke grenades blue / green / red
	*	3 IR grenades
	

*	FTL
	*	GPS
	*	Binoculars
	*	8 HE GL
	*	1 smoke GL white
	*	1 smoke GL red
	*	6 flare GL red
	*	4 flare GL yellow
	*	3 hand flare red
	*	3 hand flare green
	*	1 smoke grenades green
	*	1 smoke grenades red

*	P/CP
	*	Vector ACP
	*	Slash Bandolier 
	*	3 30rnd ACP magazines
	*	2 smoke grenades white
	*	2 hand flare red
	*	no handgun

	
	
*	VD
	*	GPS
	*	Scorpion Evo 3A1
	*	4 30rnd 9mm magazines
	*	2 hand flare red
	*	Toolkit
	
*	VG
	*	GPS
	*	Scorpion Evo 3A1
	*	2 hand flare red
	*	4 30rnd 9mm magazines
	
*	VC
	*	GPS
	*	Scorpion Evo 3A1
	*	4 30rnd 9mm magazines
	*	2 hand flare red
	*	Binoculars

	
	
*	MMG
	*	HK121 9.3 mm medium machine gun (hex)
	*	1 IR laser
	*	1 flash hider
	*	3 150rnd 9.3 mm belts
	*	handgun FNX 45 Tact
	*	2 hand flare red
	*	3 8rnd ACP
	
*	MMGAB
	*	Standard Rifleman
	*	4 150rnd 9.3 mm belts
	*	Binoculars
	
*	MMGTL
	*	Standard Fireteam Leader
	*	1 150rnd 9.3 mm belt
	
	
	
###	Addons required
*	Vanilla
*	ACE
*	CBA
*	ARCore